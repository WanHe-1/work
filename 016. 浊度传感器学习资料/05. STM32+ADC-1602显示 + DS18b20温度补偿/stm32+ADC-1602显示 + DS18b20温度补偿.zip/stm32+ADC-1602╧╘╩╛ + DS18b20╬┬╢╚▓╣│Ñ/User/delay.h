#include "stm32f10x.h"


extern  void delay_us(u16 us);
extern  void delay_ms(u16 ms);
