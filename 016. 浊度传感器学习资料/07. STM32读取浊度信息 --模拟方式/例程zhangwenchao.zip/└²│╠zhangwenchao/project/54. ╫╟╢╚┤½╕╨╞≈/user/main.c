#include "sysinc.h"

//PA4

float num[2];

 int main(void)
 {	
	u16 adcx;
	float temp;
	NVIC_init();
	SYSTICK_DelayInit();	    	 //��ʱ������ʼ��	  	  	

	GPIO_QuickInit(HW_GPIOC, GPIO_Pin_13, GPIO_Mode_Out_PP);//��ʼ����LED���ӵ�Ӳ���ӿ�
	UART_QuickInit(HW_UART1, 9600, 2, 2, ENABLE);
	 
	ADC_init(ADC_CH4);

	while(1)
	{		
		adcx=Get_Adc_Average(ADC_CH4,10);
		printf("adc4 val: %d\r\t",adcx);
		temp=(float)adcx*(3.3/4096);
		temp = temp*100/3.3;
		if(temp > 100) temp = 100;
		
		printf("adc val: %f\n",temp);
		
		SYSTICK_DelayMs(250);	 //��ʱ300ms
		PCout(13)=	!PCout(13);	
	}
 }

