/*
*************************************************************************
*Ӳ��ƽ̨: STC89C52RC
*����ƽ̨��keil 4.7
*��Ȩ    ���ߺ����ܿƼ�
*��ʼʱ�䣺2019.7.11
*����ʱ�䣺2019.7.11
*���ߣ�    ���ĳ�
*��ע��    δ��������������ҵ��;���ؾ�����
*************************************************************************
*/

#include <reg52.h>
#include "DS18B20.h"
#include "ADC0832.h"
#include "LCD1602.h"

int tmper_v = 0;
int zhuo_v = 0;

char lcd[16];


void update_value();

void delay(unsigned int i){
	while(i--);
}

void main(){
	DS18B20Init();
	LCD1602_init();
	LCD1602_Disp_ZF(0x80, "   WARTER SYS   ", 16);
		
	while(1){
		delay(30000);
		delay(30000);
		delay(30000);
		update_value();
	}  
}



void update_value(){
	tmper_v = (int)Get18B20Temp();
	zhuo_v =  get_0832_AD_data(0);
	
	zhuo_v = 100 - zhuo_v*100/255;
	

	
	lcd[0] = 'W';
	if(tmper_v < 0 || tmper_v > 100){
		lcd[1] = '-';
		lcd[2] = '-';
	}else{
		lcd[1] = tmper_v/10+48;
		lcd[2] = tmper_v%10+48;
	}
	
	lcd[3] = ' ';
	lcd[4] = ' ';	
	
	lcd[5] = 'Z';
	lcd[6] = zhuo_v/10+48;
	lcd[7] = zhuo_v%10 + 48;

	lcd[8] = ' ';
	lcd[9] = ' ';
	
	lcd[10] = ' ';
	lcd[11] = ' ';
	lcd[12] = ' ';
	lcd[13] = ' ';
	lcd[14] = ' ';
	lcd[15] = ' ';

	LCD1602_Disp_ZF(0xC0, lcd, 16);
}
